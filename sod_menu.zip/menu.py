from notebook import Notebook


class Menu:
    """
    Menu class
    """
    def __init__(self):
        self.nb = Notebook()
        self.options = {'Search': self.nb.search, 'Add': self.nb.add_note, 'Modify': self.nb.update}

    def display(self):
        """
        Returns the notes attributes of the Notebook
        :return: list
        """
        return [note.memo for note in self.nb.notes]


if __name__ == '__main__':

    # Test Case
    m = Menu()

    # Add Notes option
    m.options.get('Add')(tags='news', content='hello and hi')
    m.options.get('Add')(tags='local', content='boombastic')
    m.options.get('Add')(tags='local,test', content='testing and')
    print(m.display())

    # Search option (with matched filters)
    filtered_results1 = m.options.get('Search')(criteria='and', filter_tags=True, filter_content=True)
    print(filtered_results1)

    # Search option (without matched filters)
    filtered_results2 = m.options.get('Search')(criteria='case', filter_content=True)
    print(filtered_results2)

    # Update option (passed filtered_results1 variable that contains notes to be updated)
    updated_results1 = m.options.get('Modify')(notes=filtered_results1, new_value='new_val', filter_tags=True)
    print(updated_results1)

    for note in updated_results1:
        print(note.tags)
